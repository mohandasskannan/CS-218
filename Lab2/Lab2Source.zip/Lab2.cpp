/*
 * Course: CS218-00x
 * Project: Lab 2
 * Purpose: practice how to run unix command from C++ program
 *          system() is used to invoke an operating command from a C++ program
 *          demo cowsay command using three different cow files
 * Author: (your name)
 */

#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    const int NUM_OF_COWS = 3;
    string cowNames[] = {"gnu.cow", "tux.cow", "fox.cow"};
   
    cout << "I will demo cowsay command to you using " << NUM_OF_COWS << " cow Files stored in my VM:)" << endl;
    
    for (int i = 0; i < NUM_OF_COWS; i++)
    {
        // each time use a different cow file for cowsay command to use
        string command_str = "cowsay -f /usr/share/cowsay/cows/";
        command_str = command_str + cowNames[i];
        command_str = command_str + " Hello, CS218 Students!";
        const char* command = command_str.c_str();
        system(command);
    }
    
    return 0;
}



